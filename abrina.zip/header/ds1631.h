void ds1631_init(void);
void ds1631_conv(void);
void ds1631_temp(unsigned char *);
