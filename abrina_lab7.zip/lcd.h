void init_lcd();
void stringout(char *);
void moveto(unsigned char);
void writebyte(unsigned char, unsigned char);