#include <avr/io.h>
#include <util/delay.h>

#include "lcd.h"

void writenibble(unsigned char);
void init_io_port(unsigned char, unsigned char, unsigned char);

/*
  init_lcd - Do various things to initialize the LCD display
*/
void init_lcd() {
  _delay_ms(15);              // Delay at least 15ms

  writenibble(0x03);          // Use writenibble to send 0011
  _delay_ms(5);               // Delay at least 4msec

  writenibble(0x03);          // Use writenibble to send 0011
  _delay_us(120);             // Delay at least 100usec

  writenibble(0x03);          // Use writenibble to send 0011
  
  writenibble(0x02);          // Use writenibble to send 0010
  _delay_ms(2);               // Function Set: 4-bit interface
  
  writebyte(0x28, 0x00);      // Function Set: 4-bit interface, 2 lines
  writebyte(0x01, 0x00);      // Clear LCD
  writebyte(0x0F, 0x00);      // Display and cursor on
}

/*
  stringout - Print the contents of the character string "str"
  at the current cursor position.
*/
void stringout(char *str) {
  while(*str != '\0') {
    writebyte(*str, 0x01);
    str++;
  }
}

/*
  moveto - Move the cursor to the postion "pos"
*/
void moveto(unsigned char pos) {
  writebyte(pos, 0x00);
}

/*
  writebyte - Output a byte to the LCD display instruction register.
*/
void writebyte(unsigned char x, unsigned char rs) {
  //choose register
  PORTB = rs;
  //make sure backlight is on
  PORTB |= 0x04;

  //set upper and lower bits
  unsigned char upper = ((x & 0xF0) >> 4);
  unsigned char lower = (x & 0x0F);

  //write upper bits
  writenibble(upper);
  //write lower bits
  writenibble(lower);

  //delay to finish
  _delay_ms(2);
}

/*
  writenibble - Output four bits from "x" to the display
*/
void writenibble(unsigned char x) {
  x = ((x & 0x0F) << 4);
  PORTD = x;

  //enable signal
  PORTB |= 0x02;
  _delay_us(1);
  PORTB &= ~(0x02);
}

/*
  io_ports - Initialize each port to an input or output
*/
void init_io_port(unsigned char b, unsigned char c, unsigned char d) {
  DDRB |= b;
  DDRC |= c;
  DDRD |= d;
}