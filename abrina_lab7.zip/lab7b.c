/*************************************************************
*
*       lab7a.c - Source code for EE109 Lab 7b
*       Oscar Michael Abrina (2 PM Class)
*
*************************************************************/
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

volatile int counter = 0;
char number[10];
volatile unsigned char state = 0; //0: 00, 1: 01, 2: 10, 3: 11

int main(void) {
  PCICR |= (1<<PCIE1);
  PCMSK1 = 0x30;
  init_io_port(0x07, 0x00, 0xF0);
  PORTC = (1<<PC4) | (1<<PC5); //enable pull-up

  unsigned char a = !(PINC & (1<<PC4));
  unsigned char b = !(PINC & (1<<PC5));

  //initialize the states
  if(a && b) {
    state = 3;
  } else if (a && !b) {
    state = 1;
  } else if (!a && b) {
    state = 2;
  } else {
    state = 0;
  }

  sei();

  while(1) {
    
    init_lcd();

    sprintf(number, "%d", counter);
    stringout(number);
    moveto(0xd0); //remove cursor
  }

  while (1) {}
}

ISR(PCINT1_vect) {
  unsigned char a = !(PINC & (1<<PC4));
  unsigned char b = !(PINC & (1<<PC5));

  if(state == 0) { //00
    if(b) { //00->10
      counter--;
      state = 2;
    } else if(a) { //00->01
      counter++;
      state = 1;
    }
  } else if(state == 1) { //01
    if(a==0) { //01->00
      counter--;
      state = 0;
    } else if(b) { //01->11
      counter++;
      state = 3;
    }
  } else if (state == 2) { //1
    if (a) { //10->11
      counter--;
      state = 3;
    } else if (b==0) { //10->00
      counter++;
      state = 0;
    }
  } else if (state == 3) { //11
    if (a==0) { //11->10
      counter++;
      state = 2;
    } else if (b==0) { //11->01
      counter--;
      state = 1;
    }
  }
}