void init_serial();
unsigned char got_byte();
void get_rx_temp(char* rmtfar);
void tx_temp(char far);